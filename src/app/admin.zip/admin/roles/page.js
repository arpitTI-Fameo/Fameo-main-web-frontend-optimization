"use client";
// app/admin/roles/page.js

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store/authStore";

const ALL_ROLES = ["learner","supportAgent","moduleMaster","contentManager","superAdmin"];
const ROLE_DESC = {
  learner:        "Read topics, track progress, ask questions",
  supportAgent:   "View tickets, look up learners, read-only content",
  moduleMaster:   "Create/upload in assigned modules, submit for review",
  contentManager: "All content across all modules, approve, publish",
  superAdmin:     "Full platform access including revenue and settings",
};
const ROLE_COLOR = {
  learner:"#aaa", supportAgent:"#7ec87e", moduleMaster:"#7eb8d8",
  contentManager:"#b89fd4", superAdmin:"#C9A96E",
};

export default function RolesPage() {
  const { user } = useAuthStore();
  const [users, setUsers]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [notif, setNotif]     = useState(null);

  useEffect(() => {
    fetch("/api/admin/roles/users")
      .then(r=>r.json()).then(d=>setUsers(d.data||[]))
      .catch(()=>setUsers([
        { _id:"u1", name:"Nagi Teja",       email:"nagi@trendlance.in",   role:"superAdmin",     lastSeen:new Date().toISOString() },
        { _id:"u2", name:"Kiran Mehta",     email:"kiran@fameo.in",       role:"moduleMaster",   lastSeen:new Date(Date.now()-3600000).toISOString() },
        { _id:"u3", name:"Priya Sharma",    email:"priya@fameo.in",       role:"contentManager", lastSeen:new Date(Date.now()-7200000).toISOString() },
        { _id:"u4", name:"Ravi Support",    email:"ravi@fameo.in",        role:"supportAgent",   lastSeen:new Date(Date.now()-86400000).toISOString() },
        { _id:"u5", name:"Aarav Learner",   email:"aarav@example.com",    role:"learner",        lastSeen:new Date(Date.now()-172800000).toISOString() },
      ]))
      .finally(()=>setLoading(false));
  },[]);

  const showNotif = (msg) => { setNotif(msg); setTimeout(()=>setNotif(null),3000); };

  const changeRole = async (uid, role) => {
    if (uid === user?._id) return alert("You cannot change your own role.");
    try {
      await fetch(`/api/admin/roles/${uid}`, { method:"PATCH", headers:{"Content-Type":"application/json"}, body:JSON.stringify({role}) });
      setUsers(prev=>prev.map(u=>u._id===uid?{...u,role}:u));
      showNotif(`Role updated to ${role}`);
    } catch { showNotif("Update failed"); }
  };

  return (
    <div style={S.page}>
      {notif && <div style={S.toast}>{notif}</div>}
      <div style={S.header}>
        <div>
          <h1 style={S.heading}>Roles & Permissions</h1>
          <p style={S.sub}>Assign roles to users. Changes take effect immediately.</p>
        </div>
      </div>

      {/* Role reference */}
      <div style={S.roleRef}>
        {ALL_ROLES.map(r=>(
          <div key={r} style={{...S.roleCard, borderTop:`3px solid ${ROLE_COLOR[r]}`}}>
            <span style={{...S.roleName, color:ROLE_COLOR[r]}}>{r}</span>
            <span style={S.roleDesc}>{ROLE_DESC[r]}</span>
          </div>
        ))}
      </div>

      {loading ? <div style={S.empty}>Loading…</div> :
       <div style={S.table}>
         <div style={S.thead}><span style={{flex:2}}>User</span><span style={{flex:1}}>Current Role</span><span style={{flex:1}}>Change Role</span></div>
         {users.map(u=>(
           <div key={u._id} style={S.trow}>
             <div style={{flex:2}}>
               <p style={S.uName}>{u.name} {u._id===user?._id&&<span style={S.youBadge}>you</span>}</p>
               <p style={S.uEmail}>{u.email}</p>
             </div>
             <span style={{flex:1}}>
               <span style={{...S.rolePill, color:ROLE_COLOR[u.role]||"#aaa", background:(ROLE_COLOR[u.role]||"#aaa")+"18"}}>
                 {u.role}
               </span>
             </span>
             <div style={{flex:1}}>
               {u._id !== user?._id ? (
                 <select style={S.select} value={u.role} onChange={e=>changeRole(u._id,e.target.value)}>
                   {ALL_ROLES.map(r=><option key={r} value={r}>{r}</option>)}
                 </select>
               ) : <span style={{fontSize:11,color:"#bbb"}}>—</span>}
             </div>
           </div>
         ))}
       </div>
      }
    </div>
  );
}

const S = {
  page:    { padding:"32px 40px",maxWidth:1000,margin:"0 auto",fontFamily:"'DM Sans',sans-serif" },
  toast:   { position:"fixed",top:20,right:20,zIndex:999,padding:"12px 20px",borderRadius:8,color:"#fff",fontSize:13,fontWeight:500,background:"#7ec87e" },
  header:  { marginBottom:24 },
  heading: { fontFamily:"'Cormorant Garamond',serif",fontSize:30,fontWeight:400,color:"#1a1208",marginBottom:4 },
  sub:     { fontSize:13,color:"#aaa" },
  roleRef: { display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:12,marginBottom:28 },
  roleCard:{ background:"#fff",border:"1.5px solid #ededea",borderRadius:8,padding:"12px 14px" },
  roleName:{ display:"block",fontSize:11,fontWeight:500,letterSpacing:".04em",marginBottom:4 },
  roleDesc:{ display:"block",fontSize:10,color:"#aaa",lineHeight:1.5 },
  table:   { background:"#fff",border:"1.5px solid #ededea",borderRadius:10,overflow:"hidden" },
  thead:   { display:"flex",gap:16,padding:"10px 16px",background:"#fafaf8",borderBottom:"1px solid #ededea",fontSize:10,letterSpacing:".1em",textTransform:"uppercase",color:"#aaa" },
  trow:    { display:"flex",gap:16,padding:"12px 16px",borderBottom:"1px solid #f5f5f2",alignItems:"center" },
  uName:   { fontSize:13,fontWeight:400,color:"#1a1208",marginBottom:1,display:"flex",alignItems:"center",gap:6 },
  uEmail:  { fontSize:11,color:"#bbb" },
  youBadge:{ fontSize:9,padding:"1px 6px",background:"#C9A96E18",color:"#C9A96E",borderRadius:3,fontWeight:500 },
  rolePill:{ fontSize:10,padding:"3px 10px",borderRadius:4,fontWeight:500,letterSpacing:".04em" },
  select:  { fontSize:12,padding:"6px 10px",border:"1.5px solid #e8e8e4",borderRadius:6,outline:"none",background:"#fff",fontFamily:"'DM Sans',sans-serif",cursor:"pointer" },
  empty:   { textAlign:"center",padding:"60px 0",fontSize:13,color:"#bbb" },
};