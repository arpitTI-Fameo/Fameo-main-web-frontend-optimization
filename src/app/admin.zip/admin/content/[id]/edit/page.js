"use client";
// app/admin/content/[id]/edit/page.js  (also used for /new via [id]="new")
// Full topic editor with live preview pane

import { useState, useEffect, use } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/store/authStore";

const MODULES = [
  { id: 0, title: "Creator Foundations" },
  { id: 1, title: "Content Creation System" },
  { id: 2, title: "Studio & Team Setup" },
  { id: 3, title: "Platform Growth & Algorithms" },
  { id: 4, title: "Collabs & Community" },
  { id: 5, title: "Monetization & Brand Deals" },
  { id: 6, title: "Creator Operations & Legal" },
  { id: 7, title: "Scaling & Career Growth" },
];

const EMPTY_TOPIC = {
  title: "", shortDesc: "", moduleId: 0, level: "b", readTime: "5 min",
  body: "", checklist: [""], takeaways: [""], status: "draft",
};

export default function TopicEditor({ params }) {
  const { id }   = use(params);
  const isNew    = id === "new";
  const router   = useRouter();
  const { user } = useAuthStore();

  const [topic, setTopic]     = useState(EMPTY_TOPIC);
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving]   = useState(false);
  const [preview, setPreview] = useState(false);
  const [saved, setSaved]     = useState(false);
  const [tab, setTab]         = useState("content"); // content | meta | media

  const canPublish = ["superAdmin", "contentManager"].includes(user?.role);
  const canSubmitForReview = user?.role === "moduleMaster";

  useEffect(() => {
    if (isNew) return;
    fetch(`/api/admin/content/${id}`)
      .then(r => r.json())
      .then(d => { setTopic(d.data?.topic || EMPTY_TOPIC); setLoading(false); })
      .catch(() => setLoading(false));
  }, [id, isNew]);

  const set = (key, val) => setTopic(t => ({ ...t, [key]: val }));

  const setArrayItem = (key, idx, val) => {
    setTopic(t => {
      const arr = [...t[key]];
      arr[idx] = val;
      return { ...t, [key]: arr };
    });
  };
  const addArrayItem = (key) => setTopic(t => ({ ...t, [key]: [...t[key], ""] }));
  const removeArrayItem = (key, idx) => setTopic(t => ({ ...t, [key]: t[key].filter((_, i) => i !== idx) }));

  const save = async (overrideStatus) => {
    setSaving(true);
    const payload = { ...topic };
    if (overrideStatus) payload.status = overrideStatus;

    try {
      const url    = isNew ? "/api/admin/content" : `/api/admin/content/${id}`;
      const method = isNew ? "POST" : "PUT";
      const res    = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data   = await res.json();
      if (!isNew && data.data?.topic) setTopic(data.data.topic);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
      if (isNew && data.data?.topic?._id) router.replace(`/admin/content/${data.data.topic._id}/edit`);
    } catch (e) {
      alert("Save failed — check console");
    }
    setSaving(false);
  };

  if (loading) return <div style={{ padding: 40, fontFamily: "'DM Sans',sans-serif", color: "#aaa" }}>Loading…</div>;

  return (
    <div style={S.page}>
      {/* Top bar */}
      <div style={S.topBar}>
        <button onClick={() => router.back()} style={S.backBtn}>← Content OS</button>
        <div style={S.topCenter}>
          <StatusBadge status={topic.status} />
          {saved && <span style={S.savedNote}>✓ Saved</span>}
        </div>
        <div style={S.topActions}>
          <button onClick={() => setPreview(p => !p)} style={S.previewBtn}>
            {preview ? "Hide Preview" : "Preview"}
          </button>
          <button onClick={() => save()} disabled={saving} style={S.saveBtn}>
            {saving ? "Saving…" : "Save Draft"}
          </button>
          {canSubmitForReview && topic.status === "draft" && (
            <button onClick={() => save("review")} style={S.reviewBtn}>Submit for Review</button>
          )}
          {canPublish && topic.status !== "published" && (
            <button onClick={() => save("published")} style={S.publishBtn}>
              ◉ Publish Live
            </button>
          )}
          {canPublish && topic.status === "published" && (
            <button onClick={() => save("draft")} style={{ ...S.reviewBtn, color: "#888" }}>Unpublish</button>
          )}
        </div>
      </div>

      <div style={{ ...S.editorLayout, gridTemplateColumns: preview ? "1fr 1fr" : "1fr" }}>
        {/* ── Editor pane ── */}
        <div style={S.editorPane}>
          {/* Tabs */}
          <div style={S.tabRow}>
            {["content", "meta", "media"].map(t => (
              <button key={t} onClick={() => setTab(t)} style={{ ...S.tabBtn, borderBottom: tab === t ? "2px solid #C9A96E" : "2px solid transparent", color: tab === t ? "#1a1208" : "#aaa", fontWeight: tab === t ? 500 : 400 }}>
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>

          {/* Content Tab */}
          {tab === "content" && (
            <div style={S.tabContent}>
              <input
                style={S.titleInput}
                placeholder="Topic title…"
                value={topic.title}
                onChange={e => set("title", e.target.value)}
              />
              <textarea
                style={S.shortDescInput}
                placeholder="Short description (shown in module list)…"
                value={topic.shortDesc}
                onChange={e => set("shortDesc", e.target.value)}
                rows={2}
              />
              <label style={S.fieldLabel}>Body Content (HTML supported)</label>
              <textarea
                style={S.bodyInput}
                placeholder="Write the full article here. HTML tags are supported."
                value={topic.body}
                onChange={e => set("body", e.target.value)}
                rows={16}
              />

              {/* Takeaways */}
              <label style={S.fieldLabel}>Key Takeaways</label>
              {topic.takeaways.map((item, i) => (
                <div key={i} style={S.arrayRow}>
                  <input
                    style={S.arrayInput}
                    placeholder={`Takeaway ${i + 1}…`}
                    value={item}
                    onChange={e => setArrayItem("takeaways", i, e.target.value)}
                  />
                  <button onClick={() => removeArrayItem("takeaways", i)} style={S.removeBtn}>✕</button>
                </div>
              ))}
              <button onClick={() => addArrayItem("takeaways")} style={S.addBtn}>+ Add Takeaway</button>

              {/* Checklist */}
              <label style={{ ...S.fieldLabel, marginTop: 20 }}>Action Checklist</label>
              {topic.checklist.map((item, i) => (
                <div key={i} style={S.arrayRow}>
                  <input
                    style={S.arrayInput}
                    placeholder={`Checklist item ${i + 1}…`}
                    value={item}
                    onChange={e => setArrayItem("checklist", i, e.target.value)}
                  />
                  <button onClick={() => removeArrayItem("checklist", i)} style={S.removeBtn}>✕</button>
                </div>
              ))}
              <button onClick={() => addArrayItem("checklist")} style={S.addBtn}>+ Add Item</button>
            </div>
          )}

          {/* Meta Tab */}
          {tab === "meta" && (
            <div style={S.tabContent}>
              <div style={S.metaGrid}>
                <div>
                  <label style={S.fieldLabel}>Module</label>
                  <select style={S.metaSelect} value={topic.moduleId} onChange={e => set("moduleId", parseInt(e.target.value))}>
                    {MODULES.map(m => <option key={m.id} value={m.id}>{m.title}</option>)}
                  </select>
                </div>
                <div>
                  <label style={S.fieldLabel}>Level</label>
                  <select style={S.metaSelect} value={topic.level} onChange={e => set("level", e.target.value)}>
                    <option value="b">Beginner</option>
                    <option value="i">Intermediate</option>
                  </select>
                </div>
                <div>
                  <label style={S.fieldLabel}>Read Time</label>
                  <input style={S.metaInput} value={topic.readTime} onChange={e => set("readTime", e.target.value)} placeholder="e.g. 8 min" />
                </div>
                <div>
                  <label style={S.fieldLabel}>Product CTA (optional)</label>
                  <input style={S.metaInput} value={topic.productId || ""} onChange={e => set("productId", e.target.value || null)} placeholder="Product ID" />
                </div>
              </div>
            </div>
          )}

          {/* Media Tab */}
          {tab === "media" && (
            <div style={S.tabContent}>
              <p style={S.mediaHint}>Attach media from the Media Library. Media IDs are linked to this topic.</p>
              <div style={S.mediaIds}>
                {(topic.mediaIds || []).length === 0 ? (
                  <p style={{ color: "#bbb", fontSize: 13 }}>No media attached yet.</p>
                ) : (topic.mediaIds || []).map(mid => (
                  <div key={mid} style={S.mediaIdRow}>
                    <span style={S.mediaIdText}>{mid}</span>
                    <button onClick={() => set("mediaIds", topic.mediaIds.filter(m => m !== mid))} style={S.removeBtn}>✕</button>
                  </div>
                ))}
              </div>
              <button onClick={() => {
                const id = prompt("Enter Media ID from Media Library:");
                if (id) set("mediaIds", [...(topic.mediaIds || []), id]);
              }} style={S.addBtn}>+ Attach Media</button>
            </div>
          )}
        </div>

        {/* ── Preview pane ── */}
        {preview && (
          <div style={S.previewPane}>
            <div style={S.previewBadge}>Learner Preview</div>
            <h1 style={S.previewTitle}>{topic.title || "Untitled"}</h1>
            <p style={S.previewDesc}>{topic.shortDesc}</p>
            <div style={S.previewMeta}>
              <span>{topic.level === "b" ? "Beginner" : "Intermediate"}</span>
              <span>·</span>
              <span>{topic.readTime}</span>
              <span>·</span>
              <span>{MODULES.find(m => m.id === topic.moduleId)?.title}</span>
            </div>
            <div style={S.previewDivider} />
            <div style={S.previewBody} dangerouslySetInnerHTML={{ __html: topic.body || "<p style='color:#bbb'>Body content will appear here…</p>" }} />
            {topic.takeaways?.filter(Boolean).length > 0 && (
              <div style={S.previewTakeaways}>
                <strong style={{ fontSize: 13, color: "#1a1208" }}>Key Takeaways</strong>
                {topic.takeaways.filter(Boolean).map((t, i) => (
                  <div key={i} style={S.previewTakeawayRow}>
                    <span style={{ color: "#C9A96E", fontSize: 10 }}>◈</span>
                    <span style={{ fontSize: 13, color: "#555" }}>{t}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const conf = { published: ["#7ec87e", "#7ec87e18"], draft: ["#C9A96E", "#C9A96E18"], review: ["#7eb8d8", "#7eb8d818"], archived: ["#aaa", "#aaa18"] };
  const [color, bg] = conf[status] || conf.draft;
  return <span style={{ fontSize: 10, letterSpacing: ".1em", textTransform: "uppercase", padding: "4px 10px", borderRadius: 4, background: bg, color, fontWeight: 600 }}>{status}</span>;
}

const S = {
  page:       { display: "flex", flexDirection: "column", height: "100vh", fontFamily: "'DM Sans',sans-serif", overflow: "hidden" },
  topBar:     { display: "flex", alignItems: "center", gap: 16, padding: "10px 24px", background: "#fff", borderBottom: "1px solid #ededea", flexShrink: 0 },
  backBtn:    { fontSize: 12, color: "#888", background: "none", border: "none", cursor: "pointer", letterSpacing: ".04em" },
  topCenter:  { flex: 1, display: "flex", alignItems: "center", gap: 10 },
  savedNote:  { fontSize: 11, color: "#7ec87e", fontWeight: 500 },
  topActions: { display: "flex", gap: 8 },
  previewBtn: { fontSize: 11, padding: "7px 14px", border: "1.5px solid #e8e8e4", borderRadius: 6, background: "#fff", color: "#555", cursor: "pointer", letterSpacing: ".04em" },
  saveBtn:    { fontSize: 11, padding: "7px 14px", border: "1.5px solid #e8e8e4", borderRadius: 6, background: "#fff", color: "#1a1208", cursor: "pointer", fontWeight: 500 },
  reviewBtn:  { fontSize: 11, padding: "7px 14px", border: "1.5px solid #7eb8d844", borderRadius: 6, background: "#7eb8d818", color: "#7eb8d8", cursor: "pointer", fontWeight: 500 },
  publishBtn: { fontSize: 11, padding: "7px 16px", border: "none", borderRadius: 6, background: "#C9A96E", color: "#1a1200", cursor: "pointer", fontWeight: 600 },
  editorLayout:{ display: "grid", flex: 1, overflow: "hidden" },
  editorPane: { overflow: "auto", borderRight: "1px solid #ededea", display: "flex", flexDirection: "column" },
  tabRow:     { display: "flex", padding: "0 24px", borderBottom: "1px solid #ededea", background: "#fff", flexShrink: 0 },
  tabBtn:     { fontSize: 12, padding: "12px 16px", border: "none", background: "transparent", cursor: "pointer", fontFamily: "'DM Sans',sans-serif", transition: "all .15s" },
  tabContent: { padding: "20px 24px", flex: 1 },
  titleInput: { width: "100%", fontFamily: "'Cormorant Garamond',serif", fontSize: 28, fontWeight: 400, border: "none", outline: "none", color: "#1a1208", marginBottom: 12, letterSpacing: "-.01em", background: "transparent" },
  shortDescInput:{ width: "100%", fontSize: 14, border: "1.5px solid #e8e8e4", borderRadius: 8, padding: "10px 14px", outline: "none", fontFamily: "'DM Sans',sans-serif", resize: "vertical", marginBottom: 20 },
  fieldLabel: { display: "block", fontSize: 10, letterSpacing: ".1em", textTransform: "uppercase", color: "#aaa", marginBottom: 8 },
  bodyInput:  { width: "100%", fontSize: 13, fontFamily: "monospace", lineHeight: 1.7, border: "1.5px solid #e8e8e4", borderRadius: 8, padding: "12px 14px", outline: "none", resize: "vertical", marginBottom: 20 },
  arrayRow:   { display: "flex", gap: 8, marginBottom: 6 },
  arrayInput: { flex: 1, fontSize: 13, padding: "8px 12px", border: "1.5px solid #e8e8e4", borderRadius: 6, outline: "none", fontFamily: "'DM Sans',sans-serif" },
  removeBtn:  { fontSize: 11, padding: "4px 8px", border: "1.5px solid #e8e8e4", borderRadius: 5, background: "#fff", color: "#d49090", cursor: "pointer" },
  addBtn:     { fontSize: 11, letterSpacing: ".06em", padding: "7px 14px", border: "1.5px dashed #ddd", borderRadius: 6, background: "transparent", color: "#aaa", cursor: "pointer", marginTop: 4 },
  metaGrid:   { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 },
  metaSelect: { width: "100%", fontSize: 13, padding: "9px 12px", border: "1.5px solid #e8e8e4", borderRadius: 8, outline: "none", background: "#fff", fontFamily: "'DM Sans',sans-serif" },
  metaInput:  { width: "100%", fontSize: 13, padding: "9px 12px", border: "1.5px solid #e8e8e4", borderRadius: 8, outline: "none", fontFamily: "'DM Sans',sans-serif" },
  mediaHint:  { fontSize: 13, color: "#aaa", marginBottom: 16 },
  mediaIds:   { marginBottom: 12 },
  mediaIdRow: { display: "flex", gap: 8, alignItems: "center", marginBottom: 6 },
  mediaIdText:{ fontSize: 12, fontFamily: "monospace", color: "#555", background: "#f5f5f2", padding: "4px 10px", borderRadius: 4, flex: 1 },
  previewPane:{ overflow: "auto", padding: "32px 36px", background: "#fff" },
  previewBadge:{ fontSize: 9, letterSpacing: ".18em", textTransform: "uppercase", color: "#bbb", marginBottom: 20 },
  previewTitle:{ fontFamily: "'Cormorant Garamond',serif", fontSize: 32, fontWeight: 400, color: "#1a1208", marginBottom: 10, letterSpacing: "-.015em", lineHeight: 1.1 },
  previewDesc: { fontSize: 14, color: "#777", marginBottom: 12, lineHeight: 1.7 },
  previewMeta: { display: "flex", gap: 8, fontSize: 11, color: "#bbb", marginBottom: 16 },
  previewDivider:{ height: 1, background: "#ededea", marginBottom: 20 },
  previewBody: { fontSize: 14, lineHeight: 1.8, color: "#444", marginBottom: 24 },
  previewTakeaways:{ background: "#C9A96E0a", border: "1.5px solid #C9A96E33", borderRadius: 10, padding: "16px 18px" },
  previewTakeawayRow:{ display: "flex", gap: 8, alignItems: "flex-start", marginTop: 8 },
};