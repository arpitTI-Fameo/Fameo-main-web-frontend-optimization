"use client";
// app/admin/content/page.js — Content OS
// Create / Edit / Publish / Archive topics — changes reflect live on resources page

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/store/authStore";

const STATUS_CONFIG = {
  published: { label: "Published", color: "#7ec87e", bg: "#7ec87e18" },
  draft:     { label: "Draft",     color: "#C9A96E", bg: "#C9A96E18" },
  review:    { label: "In Review", color: "#7eb8d8", bg: "#7eb8d818" },
  archived:  { label: "Archived",  color: "#aaa",    bg: "#aaa18"    },
};

const MODULES = [
  { id: 0, title: "Creator Foundations" },
  { id: 1, title: "Content Creation System" },
  { id: 2, title: "Studio & Team Setup" },
  { id: 3, title: "Platform Growth & Algorithms" },
  { id: 4, title: "Collabs & Community" },
  { id: 5, title: "Monetization & Brand Deals" },
  { id: 6, title: "Creator Operations & Legal" },
  { id: 7, title: "Scaling & Career Growth" },
];

export default function ContentOS() {
  const { user } = useAuthStore();
  const router   = useRouter();
  const [topics, setTopics]         = useState([]);
  const [loading, setLoading]       = useState(true);
  const [filter, setFilter]         = useState({ status: "all", module: "all", search: "" });
  const [selected, setSelected]     = useState(new Set());
  const [notification, setNotif]    = useState(null);

  const canPublish = ["superAdmin", "contentManager"].includes(user?.role);
  const canDelete  = user?.role === "superAdmin";
  const moduleIds  = user?.role === "moduleMaster" ? (user?.assignedModules || []) : null;

  const fetchTopics = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (filter.status !== "all") params.set("status", filter.status);
      if (filter.module !== "all") params.set("moduleId", filter.module);
      if (filter.search) params.set("search", filter.search);
      if (moduleIds) params.set("moduleIds", moduleIds.join(","));
      const res = await fetch(`/api/admin/content?${params}`);
      const data = await res.json();
      setTopics(data.data?.topics || []);
    } catch {
      // Dev fallback
      setTopics([
        { _id: "t1", title: "Creator vs Influencer: The Fundamental Difference", moduleId: 0, status: "published", level: "b", readTime: "8 min", updatedAt: new Date().toISOString(), createdBy: "Admin" },
        { _id: "t2", title: "Choosing a Niche That Compounds", moduleId: 0, status: "published", level: "b", readTime: "12 min", updatedAt: new Date().toISOString(), createdBy: "Admin" },
        { _id: "t3", title: "Instagram Algorithm Decoded", moduleId: 3, status: "draft", level: "i", readTime: "18 min", updatedAt: new Date().toISOString(), createdBy: "Kiran M." },
        { _id: "t4", title: "Brand Deal Rate Card Template", moduleId: 5, status: "review", level: "i", readTime: "10 min", updatedAt: new Date().toISOString(), createdBy: "Priya S." },
        { _id: "t5", title: "YouTube SEO Masterclass", moduleId: 3, status: "draft", level: "i", readTime: "22 min", updatedAt: new Date().toISOString(), createdBy: "Arjun R." },
        { _id: "t6", title: "Old Algorithm Guide 2022", moduleId: 3, status: "archived", level: "b", readTime: "6 min", updatedAt: new Date().toISOString(), createdBy: "Admin" },
      ]);
    }
    setLoading(false);
  }, [filter, moduleIds]);

  useEffect(() => { fetchTopics(); }, [fetchTopics]);

  const showNotif = (msg, type = "success") => {
    setNotif({ msg, type });
    setTimeout(() => setNotif(null), 3000);
  };

  const changeStatus = async (id, status) => {
    try {
      await fetch(`/api/admin/content/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      setTopics(ts => ts.map(t => t._id === id ? { ...t, status } : t));
      showNotif(`Topic ${status === "published" ? "published" : status === "archived" ? "archived" : "updated"} — live on Learner Hub`);
    } catch { showNotif("Failed to update", "error"); }
  };

  const bulkAction = async (action) => {
    const ids = [...selected];
    await Promise.all(ids.map(id => changeStatus(id, action)));
    setSelected(new Set());
  };

  const deleteTopic = async (id) => {
    if (!confirm("Permanently delete this topic? This cannot be undone.")) return;
    await fetch(`/api/admin/content/${id}`, { method: "DELETE" });
    setTopics(ts => ts.filter(t => t._id !== id));
    showNotif("Topic deleted");
  };

  const filtered = topics.filter(t => {
    if (filter.status !== "all" && t.status !== filter.status) return false;
    if (filter.module !== "all" && t.moduleId !== parseInt(filter.module)) return false;
    if (filter.search && !t.title.toLowerCase().includes(filter.search.toLowerCase())) return false;
    return true;
  });

  return (
    <div style={S.page}>
      {/* Notification toast */}
      {notification && (
        <div style={{ ...S.toast, background: notification.type === "error" ? "#d49090" : "#7ec87e" }}>
          {notification.msg}
        </div>
      )}

      {/* Header */}
      <div style={S.header}>
        <div>
          <h1 style={S.heading}>Content OS</h1>
          <p style={S.sub}>All topics across all modules. Changes publish live to the Learner Hub.</p>
        </div>
        <Link href="/admin/content/new" style={S.newBtn}>+ New Topic</Link>
      </div>

      {/* Filters */}
      <div style={S.filters}>
        <input
          style={S.search}
          placeholder="Search topics…"
          value={filter.search}
          onChange={e => setFilter(f => ({ ...f, search: e.target.value }))}
        />
        <select style={S.select} value={filter.status} onChange={e => setFilter(f => ({ ...f, status: e.target.value }))}>
          <option value="all">All Status</option>
          <option value="published">Published</option>
          <option value="draft">Draft</option>
          <option value="review">In Review</option>
          <option value="archived">Archived</option>
        </select>
        <select style={S.select} value={filter.module} onChange={e => setFilter(f => ({ ...f, module: e.target.value }))}>
          <option value="all">All Modules</option>
          {MODULES.map(m => <option key={m.id} value={m.id}>{m.title}</option>)}
        </select>
        {selected.size > 0 && (
          <div style={S.bulkBar}>
            <span style={S.bulkCount}>{selected.size} selected</span>
            {canPublish && <button style={S.bulkBtn} onClick={() => bulkAction("published")}>Publish all</button>}
            <button style={{ ...S.bulkBtn, color: "#d49090" }} onClick={() => bulkAction("archived")}>Archive all</button>
            <button style={{ ...S.bulkBtn, color: "#aaa" }} onClick={() => setSelected(new Set())}>Clear</button>
          </div>
        )}
      </div>

      {/* Table */}
      <div style={S.table}>
        <div style={S.tableHead}>
          <input type="checkbox" onChange={e => setSelected(e.target.checked ? new Set(filtered.map(t => t._id)) : new Set())} style={{ marginRight: 4 }} />
          <span style={{ flex: 3 }}>Title</span>
          <span style={{ flex: 1 }}>Module</span>
          <span style={{ flex: 1 }}>Status</span>
          <span style={{ flex: 1 }}>Level</span>
          <span style={{ flex: 1 }}>Updated</span>
          <span style={{ flex: 1 }}>Actions</span>
        </div>

        {loading ? (
          <div style={S.tableEmpty}>Loading…</div>
        ) : filtered.length === 0 ? (
          <div style={S.tableEmpty}>No topics found</div>
        ) : filtered.map(topic => {
          const sc = STATUS_CONFIG[topic.status] || STATUS_CONFIG.draft;
          const mod = MODULES.find(m => m.id === topic.moduleId);
          return (
            <div key={topic._id} style={{ ...S.tableRow, background: selected.has(topic._id) ? "#f0f8f0" : "#fff" }}>
              <input
                type="checkbox"
                checked={selected.has(topic._id)}
                onChange={e => {
                  const next = new Set(selected);
                  e.target.checked ? next.add(topic._id) : next.delete(topic._id);
                  setSelected(next);
                }}
                style={{ marginRight: 4 }}
              />
              <div style={{ flex: 3, minWidth: 0 }}>
                <span style={S.topicTitle}>{topic.title}</span>
                <span style={S.topicMeta}>by {topic.createdBy} · {topic.readTime}</span>
              </div>
              <span style={{ flex: 1, fontSize: 11, color: "#888" }}>{mod?.title || `Module ${topic.moduleId}`}</span>
              <span style={{ flex: 1 }}>
                <span style={{ ...S.statusPill, background: sc.bg, color: sc.color }}>{sc.label}</span>
              </span>
              <span style={{ flex: 1, fontSize: 11, color: "#888" }}>{topic.level === "b" ? "Beginner" : "Intermediate"}</span>
              <span style={{ flex: 1, fontSize: 11, color: "#bbb" }}>{timeAgo(topic.updatedAt)}</span>
              <div style={{ flex: 1, display: "flex", gap: 4, flexWrap: "wrap" }}>
                <Link href={`/admin/content/${topic._id}/edit`} style={S.actionBtn}>Edit</Link>
                {topic.status !== "published" && canPublish && (
                  <button style={{ ...S.actionBtn, color: "#3a7c3a", borderColor: "#7ec87e44" }} onClick={() => changeStatus(topic._id, "published")}>
                    Publish
                  </button>
                )}
                {topic.status === "published" && canPublish && (
                  <button style={{ ...S.actionBtn, color: "#888" }} onClick={() => changeStatus(topic._id, "draft")}>
                    Unpublish
                  </button>
                )}
                {topic.status !== "archived" && (
                  <button style={{ ...S.actionBtn, color: "#d49090", borderColor: "#d4909044" }} onClick={() => changeStatus(topic._id, "archived")}>
                    Archive
                  </button>
                )}
                {canDelete && (
                  <button style={{ ...S.actionBtn, color: "#c00", borderColor: "#c0000044" }} onClick={() => deleteTopic(topic._id)}>
                    Delete
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div style={S.tableFooter}>
        Showing {filtered.length} of {topics.length} topics
        {canPublish && <span style={S.liveNote}>◉ Changes publish live to Learner Hub instantly</span>}
      </div>
    </div>
  );
}

function timeAgo(iso) {
  const d = Math.floor((Date.now() - new Date(iso)) / 60000);
  if (d < 1) return "just now";
  if (d < 60) return `${d}m ago`;
  if (d < 1440) return `${Math.floor(d / 60)}h ago`;
  return `${Math.floor(d / 1440)}d ago`;
}

const S = {
  page:        { padding: "32px 40px", maxWidth: 1200, margin: "0 auto", fontFamily: "'DM Sans',sans-serif" },
  toast:       { position: "fixed", top: 20, right: 20, zIndex: 999, padding: "12px 20px", borderRadius: 8, color: "#fff", fontSize: 13, fontWeight: 500, boxShadow: "0 4px 20px rgba(0,0,0,.15)" },
  header:      { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 },
  heading:     { fontFamily: "'Cormorant Garamond',serif", fontSize: 30, fontWeight: 400, color: "#1a1208", marginBottom: 4 },
  sub:         { fontSize: 13, color: "#aaa" },
  newBtn:      { fontSize: 11, letterSpacing: ".1em", textTransform: "uppercase", padding: "10px 20px", background: "#1a1208", color: "#F0E8D6", borderRadius: 6, textDecoration: "none", fontWeight: 500 },
  filters:     { display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap", alignItems: "center" },
  search:      { fontSize: 12, padding: "8px 14px", border: "1.5px solid #e8e8e4", borderRadius: 8, outline: "none", width: 220, fontFamily: "'DM Sans',sans-serif" },
  select:      { fontSize: 12, padding: "8px 12px", border: "1.5px solid #e8e8e4", borderRadius: 8, outline: "none", background: "#fff", fontFamily: "'DM Sans',sans-serif", cursor: "pointer" },
  bulkBar:     { display: "flex", alignItems: "center", gap: 8, padding: "6px 12px", background: "#1a1208", borderRadius: 8 },
  bulkCount:   { fontSize: 11, color: "#F0E8D6", fontWeight: 500 },
  bulkBtn:     { fontSize: 11, background: "none", border: "none", color: "#F0E8D6", cursor: "pointer", letterSpacing: ".04em" },
  table:       { background: "#fff", border: "1.5px solid #ededea", borderRadius: 10, overflow: "hidden" },
  tableHead:   { display: "flex", alignItems: "center", gap: 12, padding: "10px 16px", background: "#fafaf8", borderBottom: "1px solid #ededea", fontSize: 10, letterSpacing: ".1em", textTransform: "uppercase", color: "#aaa" },
  tableRow:    { display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", borderBottom: "1px solid #f5f5f2", transition: "background .1s" },
  tableEmpty:  { padding: "40px 0", textAlign: "center", fontSize: 13, color: "#bbb" },
  tableFooter: { padding: "12px 16px", fontSize: 11, color: "#bbb", display: "flex", justifyContent: "space-between" },
  topicTitle:  { display: "block", fontSize: 13, fontWeight: 400, color: "#1a1208", marginBottom: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" },
  topicMeta:   { display: "block", fontSize: 10, color: "#bbb" },
  statusPill:  { fontSize: 9, letterSpacing: ".1em", textTransform: "uppercase", padding: "3px 8px", borderRadius: 4, fontWeight: 600 },
  actionBtn:   { fontSize: 10, padding: "4px 10px", border: "1.5px solid #e8e8e4", borderRadius: 5, background: "#fff", cursor: "pointer", color: "#555", textDecoration: "none", letterSpacing: ".03em" },
  liveNote:    { color: "#7ec87e", fontWeight: 500 },
};