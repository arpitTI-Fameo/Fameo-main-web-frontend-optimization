"use client";
// app/admin/page.js  — Overview Dashboard

import { useState, useEffect } from "react";
import Link from "next/link";
import { useAuthStore } from "@/store/authStore";

const ROLE_ACCENT = {
  superAdmin: "#C9A96E", moduleMaster: "#7eb8d8",
  contentManager: "#b89fd4", supportAgent: "#7ec87e",
};

export default function AdminOverview() {
  const { user } = useAuthStore();
  const accent   = ROLE_ACCENT[user?.role] || "#C9A96E";
  const [stats, setStats]       = useState(null);
  const [pending, setPending]   = useState([]);
  const [activity, setActivity] = useState([]);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/admin/stats").then(r => r.json()),
      fetch("/api/admin/approvals?status=pending&limit=5").then(r => r.json()),
      fetch("/api/admin/activity?limit=8").then(r => r.json()),
    ]).then(([s, p, a]) => {
      setStats(s.data);
      setPending(p.data?.approvals || []);
      setActivity(a.data?.activity || []);
      setLoading(false);
    }).catch(() => {
      // Dev fallback
      setStats({ totalTopics: 48, publishedTopics: 34, draftTopics: 9, pendingApprovals: 3, totalLearners: 1240, activeLearners: 387, totalProducts: 12, revenue: "₹2,84,000" });
      setPending([
        { _id: "1", title: "Reels Algorithm Deep Dive", submittedByName: "Kiran M.", type: "topic", submittedAt: new Date().toISOString() },
        { _id: "2", title: "Brand Deal Template Pack", submittedByName: "Priya S.", type: "product", submittedAt: new Date().toISOString() },
        { _id: "3", title: "Instagram Growth Masterclass", submittedByName: "Arjun R.", type: "topic", submittedAt: new Date().toISOString() },
      ]);
      setActivity([
        { action: "Published", target: "Creator Foundations — Lesson 3", user: "Admin", time: "2m ago", color: "#7ec87e" },
        { action: "Approved", target: "Monetization Template Pack", user: "Admin", time: "14m ago", color: "#C9A96E" },
        { action: "Archived", target: "Old Brand Deal Guide", user: "Kiran M.", time: "1h ago", color: "#d49090" },
        { action: "Enrolled", target: "45 new learners today", user: "system", time: "2h ago", color: "#7eb8d8" },
      ]);
      setLoading(false);
    });
  }, []);

  if (loading) return <div style={S.loading}><span style={{ color: accent }}>◈</span> Loading…</div>;

  const statCards = [
    { label: "Published Topics", value: stats?.publishedTopics, sub: `${stats?.draftTopics} drafts`, accent: "#7ec87e" },
    { label: "Pending Approvals", value: stats?.pendingApprovals, sub: "need review", accent: "#C9A96E", href: "/admin/approvals" },
    { label: "Active Learners", value: stats?.activeLearners, sub: `of ${stats?.totalLearners?.toLocaleString()} total`, accent: "#7eb8d8" },
    { label: "Revenue (MTD)", value: stats?.revenue, sub: "this month", accent: "#b89fd4", superAdminOnly: true },
  ];

  return (
    <div style={S.page}>
      {/* Header */}
      <div style={S.header}>
        <div>
          <h1 style={S.heading}>Good {getGreeting()}, {user?.name?.split(" ")[0] || "Admin"}</h1>
          <p style={S.subheading}>Here's what's happening on Fameo right now.</p>
        </div>
        <div style={S.headerActions}>
          <Link href="/admin/content/new" style={{ ...S.btnPrimary, background: accent, color: "#1a1208" }}>
            + New Topic
          </Link>
        </div>
      </div>

      {/* Stat Cards */}
      <div style={S.statsGrid}>
        {statCards
          .filter(c => !c.superAdminOnly || user?.role === "superAdmin")
          .map(card => (
            <Link key={card.label} href={card.href || "#"} style={{ ...S.statCard, textDecoration: "none", borderTop: `3px solid ${card.accent}` }}>
              <span style={S.statValue}>{card.value ?? "—"}</span>
              <span style={S.statLabel}>{card.label}</span>
              <span style={S.statSub}>{card.sub}</span>
            </Link>
          ))}
      </div>

      <div style={S.twoCol}>
        {/* Pending Approvals */}
        <div style={S.card}>
          <div style={S.cardHeader}>
            <h2 style={S.cardTitle}>Pending Approvals</h2>
            <Link href="/admin/approvals" style={{ ...S.cardLink, color: accent }}>View all →</Link>
          </div>
          {pending.length === 0 ? (
            <p style={S.emptyMsg}>All caught up ✓</p>
          ) : pending.map(item => (
            <div key={item._id} style={S.approvalRow}>
              <div style={{ ...S.approvalType, background: item.type === "topic" ? "#7ec87e22" : "#C9A96E22", color: item.type === "topic" ? "#3a7c3a" : "#7a5a1a" }}>
                {item.type}
              </div>
              <div style={S.approvalInfo}>
                <span style={S.approvalTitle}>{item.title}</span>
                <span style={S.approvalMeta}>by {item.submittedByName} · {timeAgo(item.submittedAt)}</span>
              </div>
              <div style={S.approvalActions}>
                <ApproveBtn id={item._id} accent={accent} onDone={() => setPending(p => p.filter(x => x._id !== item._id))} />
              </div>
            </div>
          ))}
        </div>

        {/* Activity Feed */}
        <div style={S.card}>
          <div style={S.cardHeader}>
            <h2 style={S.cardTitle}>Recent Activity</h2>
          </div>
          {activity.map((a, i) => (
            <div key={i} style={S.activityRow}>
              <span style={{ ...S.activityDot, background: a.color }} />
              <div>
                <span style={S.activityAction}>{a.action}</span>
                <span style={S.activityTarget}> — {a.target}</span>
                <div style={S.activityMeta}>{a.user} · {a.time}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Feature Flags — super admin only */}
      {user?.role === "superAdmin" && <FeatureFlags accent={accent} />}
    </div>
  );
}

/* ── Approve/Reject inline buttons ── */
function ApproveBtn({ id, accent, onDone }) {
  const [loading, setLoading] = useState(false);
  const approve = async () => {
    setLoading(true);
    await fetch(`/api/admin/approvals/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: "approved" }) });
    onDone();
  };
  return (
    <div style={{ display: "flex", gap: 6 }}>
      <button onClick={approve} disabled={loading} style={{ ...S.approveBtn, background: accent + "22", color: accent, border: `1px solid ${accent}44` }}>
        {loading ? "…" : "✓"}
      </button>
      <button onClick={onDone} style={{ ...S.approveBtn, background: "#d4909022", color: "#d49090", border: "1px solid #d4909044" }}>✕</button>
    </div>
  );
}

/* ── Feature Flags Panel ── */
function FeatureFlags({ accent }) {
  const [flags, setFlags] = useState({
    progressTracking: true, moduleFollowing: true, qaComments: true,
    shopAndCTAs: true, contentApprovalWorkflow: true, moduleGlossary: false,
    liveSessionScheduling: false, learnerRegistration: true,
  });
  const [saving, setSaving] = useState(false);

  const toggle = async (key) => {
    const next = { ...flags, [key]: !flags[key] };
    setFlags(next);
    setSaving(true);
    await fetch("/api/admin/settings/features", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ [key]: next[key] }),
    }).catch(() => {});
    setSaving(false);
  };

  const FLAG_LABELS = {
    progressTracking: "Progress Tracking", moduleFollowing: "Module Following",
    qaComments: "Q&A Comments", shopAndCTAs: "Shop & CTAs",
    contentApprovalWorkflow: "Approval Workflow", moduleGlossary: "Module Glossary",
    liveSessionScheduling: "Live Sessions", learnerRegistration: "Learner Registration",
  };

  return (
    <div style={S.card}>
      <div style={S.cardHeader}>
        <h2 style={S.cardTitle}>Feature Flags</h2>
        <span style={S.savingIndicator}>{saving ? "Saving…" : "Live — changes reflect instantly"}</span>
      </div>
      <div style={S.flagsGrid}>
        {Object.entries(flags).map(([key, val]) => (
          <div key={key} style={S.flagRow}>
            <span style={S.flagLabel}>{FLAG_LABELS[key]}</span>
            <button onClick={() => toggle(key)} style={{ ...S.toggle, background: val ? accent : "#ddd" }}>
              <span style={{ ...S.toggleThumb, transform: val ? "translateX(18px)" : "translateX(2px)" }} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  return "evening";
}
function timeAgo(iso) {
  const d = Math.floor((Date.now() - new Date(iso)) / 60000);
  if (d < 1) return "just now";
  if (d < 60) return `${d}m ago`;
  return `${Math.floor(d / 60)}h ago`;
}

const S = {
  page:       { padding: "32px 40px", maxWidth: 1200, margin: "0 auto" },
  loading:    { display: "flex", alignItems: "center", justifyContent: "center", height: "60vh", fontSize: 18, gap: 10, fontFamily: "'DM Sans',sans-serif" },
  header:     { display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 32 },
  heading:    { fontFamily: "'Cormorant Garamond',serif", fontSize: 32, fontWeight: 400, color: "#1a1208", letterSpacing: "-.01em", marginBottom: 4 },
  subheading: { fontSize: 13, color: "#aaa" },
  headerActions: { display: "flex", gap: 10 },
  btnPrimary: { fontSize: 11, letterSpacing: ".1em", textTransform: "uppercase", padding: "10px 20px", border: "none", borderRadius: 6, fontWeight: 600, textDecoration: "none", cursor: "pointer" },

  statsGrid:  { display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 16, marginBottom: 24 },
  statCard:   { background: "#fff", borderRadius: 10, padding: "20px 20px 16px", border: "1.5px solid #ededea", display: "flex", flexDirection: "column", gap: 2, transition: "transform .2s" },
  statValue:  { fontFamily: "'Cormorant Garamond',serif", fontSize: 36, fontWeight: 300, color: "#1a1208", lineHeight: 1, letterSpacing: "-.02em" },
  statLabel:  { fontSize: 12, fontWeight: 500, color: "#555", marginTop: 6 },
  statSub:    { fontSize: 11, color: "#bbb" },

  twoCol:     { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 24 },
  card:       { background: "#fff", borderRadius: 10, border: "1.5px solid #ededea", overflow: "hidden", marginBottom: 16 },
  cardHeader: { padding: "16px 20px", borderBottom: "1px solid #f0f0ee", display: "flex", alignItems: "center", justifyContent: "space-between" },
  cardTitle:  { fontFamily: "'Cormorant Garamond',serif", fontSize: 18, fontWeight: 400, color: "#1a1208" },
  cardLink:   { fontSize: 12, textDecoration: "none", letterSpacing: ".04em" },
  emptyMsg:   { padding: "20px", fontSize: 13, color: "#bbb", textAlign: "center" },

  approvalRow:    { display: "flex", alignItems: "center", gap: 12, padding: "12px 20px", borderBottom: "1px solid #f5f5f2" },
  approvalType:   { fontSize: 9, letterSpacing: ".1em", textTransform: "uppercase", padding: "3px 8px", borderRadius: 4, fontWeight: 600, flexShrink: 0 },
  approvalInfo:   { flex: 1, minWidth: 0 },
  approvalTitle:  { display: "block", fontSize: 13, fontWeight: 400, color: "#1a1208", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" },
  approvalMeta:   { fontSize: 11, color: "#bbb" },
  approvalActions:{ flexShrink: 0 },
  approveBtn:     { fontSize: 12, padding: "4px 10px", borderRadius: 5, cursor: "pointer", fontWeight: 600 },

  activityRow:    { display: "flex", gap: 12, padding: "11px 20px", borderBottom: "1px solid #f5f5f2", alignItems: "flex-start" },
  activityDot:    { width: 7, height: 7, borderRadius: "50%", flexShrink: 0, marginTop: 5 },
  activityAction: { fontSize: 12, fontWeight: 500, color: "#1a1208" },
  activityTarget: { fontSize: 12, color: "#666" },
  activityMeta:   { fontSize: 10, color: "#bbb", marginTop: 2 },

  savingIndicator:{ fontSize: 10, color: "#bbb", letterSpacing: ".04em" },
  flagsGrid:      { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2 },
  flagRow:        { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 20px", borderBottom: "1px solid #f5f5f2" },
  flagLabel:      { fontSize: 12, color: "#555" },
  toggle:         { width: 38, height: 22, borderRadius: 11, border: "none", cursor: "pointer", position: "relative", transition: "background .2s", flexShrink: 0 },
  toggleThumb:    { position: "absolute", top: 2, width: 18, height: 18, borderRadius: "50%", background: "#fff", transition: "transform .2s", boxShadow: "0 1px 4px rgba(0,0,0,0.2)" },
};