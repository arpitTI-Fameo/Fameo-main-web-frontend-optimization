"use client";
// app/admin/support/page.js
import { useState } from "react";
export default function SupportPage() {
  const [tickets] = useState([
    { _id:"s1", subject:"Can't access Module 3",    learner:"Aarav Sharma",  status:"open",     created:new Date(Date.now()-3600000).toISOString()   },
    { _id:"s2", subject:"Video not loading",         learner:"Priya Nair",    status:"open",     created:new Date(Date.now()-7200000).toISOString()   },
    { _id:"s3", subject:"Certificate not received",  learner:"Rohit Verma",   status:"resolved", created:new Date(Date.now()-86400000).toISOString()  },
    { _id:"s4", subject:"Wrong price shown",         learner:"Sneha K.",      status:"open",     created:new Date(Date.now()-172800000).toISOString() },
  ]);
  const [active, setActive] = useState(null);
  const [reply, setReply]   = useState("");

  return (
    <div style={S.page}>
      <div style={S.header}>
        <h1 style={S.heading}>Support</h1>
        <p style={S.sub}>{tickets.filter(t=>t.status==="open").length} open tickets</p>
      </div>
      <div style={S.layout}>
        <div style={S.ticketList}>
          {tickets.map(t=>(
            <div key={t._id} onClick={()=>setActive(t)} style={{...S.ticket, background:active?._id===t._id?"#fef9f0":"#fff", borderLeft:active?._id===t._id?"3px solid #C9A96E":"3px solid transparent"}}>
              <div style={S.ticketTop}>
                <span style={S.ticketSubject}>{t.subject}</span>
                <span style={{...S.statusDot, background:t.status==="open"?"#d49090":"#7ec87e"}}/>
              </div>
              <p style={S.ticketMeta}>{t.learner} · {timeAgo(t.created)}</p>
            </div>
          ))}
        </div>
        <div style={S.ticketDetail}>
          {!active ? <div style={S.emptyDetail}>Select a ticket</div> : <>
            <h2 style={S.detailTitle}>{active.subject}</h2>
            <p style={S.detailMeta}>From <strong>{active.learner}</strong> · {timeAgo(active.created)}</p>
            <div style={S.replyBox}>
              <textarea style={S.replyInput} value={reply} onChange={e=>setReply(e.target.value)} placeholder="Type your reply…" rows={4}/>
              <div style={{display:"flex",gap:10,justifyContent:"flex-end",marginTop:10}}>
                <button style={S.resolveBtn} onClick={()=>setActive(null)}>Mark Resolved</button>
                <button style={S.replyBtn} onClick={()=>{ alert("Reply sent!"); setReply(""); }}>Send Reply</button>
              </div>
            </div>
          </>}
        </div>
      </div>
    </div>
  );
}
function timeAgo(iso){const d=Math.floor((Date.now()-new Date(iso))/60000);if(d<60)return `${d}m ago`;if(d<1440)return `${Math.floor(d/60)}h ago`;return `${Math.floor(d/1440)}d ago`;}
const S={
  page:{padding:"32px 40px",maxWidth:1100,margin:"0 auto",fontFamily:"'DM Sans',sans-serif"},
  header:{marginBottom:24},
  heading:{fontFamily:"'Cormorant Garamond',serif",fontSize:30,fontWeight:400,color:"#1a1208",marginBottom:4},
  sub:{fontSize:13,color:"#aaa"},
  layout:{display:"grid",gridTemplateColumns:"300px 1fr",gap:16,height:"calc(100vh - 220px)"},
  ticketList:{background:"#fff",border:"1.5px solid #ededea",borderRadius:10,overflow:"auto"},
  ticket:{padding:"14px 16px",borderBottom:"1px solid #f5f5f2",cursor:"pointer",transition:"background .1s",borderLeft:"3px solid transparent"},
  ticketTop:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4},
  ticketSubject:{fontSize:12,fontWeight:500,color:"#1a1208"},
  statusDot:{width:7,height:7,borderRadius:"50%",flexShrink:0},
  ticketMeta:{fontSize:10,color:"#bbb"},
  ticketDetail:{background:"#fff",border:"1.5px solid #ededea",borderRadius:10,padding:"24px"},
  emptyDetail:{display:"flex",alignItems:"center",justifyContent:"center",height:"100%",fontSize:13,color:"#bbb"},
  detailTitle:{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:400,color:"#1a1208",marginBottom:6},
  detailMeta:{fontSize:12,color:"#aaa",marginBottom:20},
  replyBox:{},
  replyInput:{width:"100%",fontSize:13,padding:"12px",border:"1.5px solid #e8e8e4",borderRadius:8,outline:"none",resize:"vertical",fontFamily:"'DM Sans',sans-serif"},
  resolveBtn:{fontSize:11,padding:"8px 16px",border:"1.5px solid #7ec87e44",background:"#7ec87e18",color:"#3a7c3a",borderRadius:6,cursor:"pointer"},
  replyBtn:{fontSize:11,padding:"8px 16px",background:"#1a1208",color:"#F0E8D6",border:"none",borderRadius:6,cursor:"pointer",fontWeight:500},
};